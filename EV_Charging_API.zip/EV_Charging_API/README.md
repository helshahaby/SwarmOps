# EV Charging Management API

FastAPI service for users, stations, charging sessions, energy and reporting.

## Run locally
    cp .env.example .env   # set JWT_SECRET and DATABASE_URL
    pip install -r requirements.txt
    uvicorn app.main:app --reload

## Test
    pytest -q
