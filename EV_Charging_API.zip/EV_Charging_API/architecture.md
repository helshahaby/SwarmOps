# Architecture

## Components
- api-gateway (FastAPI app, routing, middleware)
- auth-service (JWT issue/verify, RBAC)
- station-service (stations, connectors)
- session-service (charging lifecycle, energy metering)
- reporting-service (aggregations, CSV)
- PostgreSQL (primary store), Redis (rate limits, locks)

## Data flow
Client -> Gateway -> Auth middleware -> Service -> Repository -> PostgreSQL

## API
POST /auth/register | POST /auth/login
GET/POST /stations | GET/PATCH/DELETE /stations/{id}
POST /sessions/start | POST /sessions/{id}/stop | GET /sessions/{id}
GET /reports/energy?from=&to=&group_by=

## Schema
users(id, email, password_hash, role, created_at)
stations(id, name, location, status)
connectors(id, station_id, type, max_kw, status)
sessions(id, user_id, connector_id, started_at, ended_at, energy_kwh, status)
