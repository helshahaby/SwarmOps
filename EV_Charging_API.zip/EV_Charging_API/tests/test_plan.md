# Test Plan (24 cases)
- Auth: register, login, wrong password, missing token (T-07), expired token (T-08), role checks
- Stations: CRUD, validation, operator-only writes
- Sessions: start, stop, busy connector (409), foreign session stop (403)
- Reports: date range, grouping, empty range, CSV export
