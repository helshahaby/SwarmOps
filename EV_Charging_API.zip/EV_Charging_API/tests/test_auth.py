def test_missing_token_returns_401(client):
    assert client.get("/sessions/abc").status_code == 401

def test_expired_token_returns_401(client, expired_token):
    r = client.get("/sessions/abc", headers={"Authorization": f"Bearer {expired_token}"})
    assert r.status_code == 401

def test_driver_cannot_create_station(client, driver_token):
    r = client.post("/stations", json={"name": "X"}, headers={"Authorization": f"Bearer {driver_token}"})
    assert r.status_code == 403
