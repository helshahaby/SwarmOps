import os
import pytest
from datetime import datetime, timedelta, timezone
from fastapi import Depends
from fastapi.testclient import TestClient
import jwt

os.environ["JWT_SECRET"] = os.environ.get("JWT_SECRET", "super-secret-key-for-testing-12345")

from app.main import app
from app.security.auth import create_token, current_user, ALGORITHM, JWT_SECRET

# Register a protected test endpoint for /sessions/{id}
@app.get("/sessions/{session_id}")
async def get_session(session_id: str, user=Depends(current_user)):
    return {"session_id": session_id, "user": user["sub"]}

@pytest.fixture
def client():
    return TestClient(app)

@pytest.fixture
def driver_token():
    return create_token("user-driver-1", "driver")

@pytest.fixture
def expired_token():
    past = datetime.now(timezone.utc) - timedelta(minutes=15)
    return jwt.encode({"sub": "user-driver-1", "role": "driver", "exp": past}, JWT_SECRET, ALGORITHM)
