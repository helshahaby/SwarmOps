# Deployment Guide
1. Provision PostgreSQL 15 and Redis 7.
2. Set env vars from .env.example (generate JWT_SECRET with: openssl rand -hex 32).
3. Run migrations: alembic upgrade head
4. Start: gunicorn -k uvicorn.workers.UvicornWorker app.main:app
5. Put behind TLS-terminating reverse proxy.
6. Enable login rate limiting (S-03) before public launch.
