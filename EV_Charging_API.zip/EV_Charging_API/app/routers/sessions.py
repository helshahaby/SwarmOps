from fastapi import APIRouter, Depends, HTTPException
from app.security.auth import current_user
from app.services import session_service
from app.schemas import StartSession, SessionOut

router = APIRouter()

@router.post("/start", response_model=SessionOut)
async def start(body: StartSession, user=Depends(current_user)):
    # Row-level lock on connector prevents double booking
    session = await session_service.start(user["sub"], body.connector_id)
    if session is None:
        raise HTTPException(409, "Connector busy")
    return session

@router.post("/{session_id}/stop", response_model=SessionOut)
async def stop(session_id: str, user=Depends(current_user)):
    return await session_service.stop(user["sub"], session_id)
