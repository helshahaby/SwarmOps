from fastapi import APIRouter, Depends
from app.security.auth import require_role

router = APIRouter()

@router.post("")
async def create_station(payload: dict, user=Depends(require_role("operator", "admin"))):
    return {"status": "created", "name": payload.get("name")}
