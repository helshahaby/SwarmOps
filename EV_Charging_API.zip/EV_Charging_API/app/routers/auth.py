from fastapi import APIRouter
from pydantic import BaseModel
import jwt, os
from datetime import datetime, timedelta, timezone

router = APIRouter()
SECRET = os.environ.get("JWT_SECRET", "super-secret-key-for-testing-12345")

class TokenRequest(BaseModel):
    user_id: str = "driver_42"
    role: str = "driver"  # "driver" or "operator"

@router.post("/token")
def create_token(req: TokenRequest):
    payload = {
        "sub": req.user_id,
        "role": req.role,
        "exp": datetime.now(timezone.utc) + timedelta(hours=2)
    }
    token = jwt.encode(payload, SECRET, algorithm="HS256")
    return {"access_token": token, "token_type": "bearer", "role": req.role}
