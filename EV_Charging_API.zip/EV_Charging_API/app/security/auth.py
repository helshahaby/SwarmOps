import os
from datetime import datetime, timedelta, timezone
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt

JWT_SECRET = os.environ["JWT_SECRET"]  # v2: no default fallback secret
ALGORITHM = "HS256"
bearer = HTTPBearer(auto_error=False)

def create_token(user_id: str, role: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=30)
    return jwt.encode({"sub": user_id, "role": role, "exp": exp}, JWT_SECRET, ALGORITHM)

def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    # v2: explicit 401 for missing / malformed / expired tokens (fixes T-07, T-08)
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing token")
    try:
        return jwt.decode(creds.credentials, JWT_SECRET, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")

def require_role(*roles: str):
    def checker(user=Depends(current_user)):
        if user.get("role") not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient role")
        return user
    return checker
