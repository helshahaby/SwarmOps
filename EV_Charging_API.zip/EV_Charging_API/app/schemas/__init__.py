from pydantic import BaseModel

class StartSession(BaseModel):
    connector_id: str

class SessionOut(BaseModel):
    id: str = "sess-01"
    connector_id: str = "conn-01"
    status: str = "active"
