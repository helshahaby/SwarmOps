async def start(user_id: str, connector_id: str):
    if connector_id == "busy":
        return None
    return {"id": "sess-01", "connector_id": connector_id, "status": "active"}

async def stop(user_id: str, session_id: str):
    return {"id": session_id, "status": "stopped"}
