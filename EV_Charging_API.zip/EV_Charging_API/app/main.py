from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from app.routers import auth, stations, sessions

app = FastAPI(
    title="EV Charging Management API",
    version="1.0.0",
    description="Backend API and Interactive Dashboard for EV Charging"
)

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(stations.router, prefix="/stations", tags=["Stations"])
app.include_router(sessions.router, prefix="/sessions", tags=["Sessions"])

@app.get("/", response_class=HTMLResponse)
def visual_dashboard():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>EV Charging Hub — Live Dashboard</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-900 text-slate-100 min-h-screen p-8 font-sans">
      <div class="max-w-4xl mx-auto space-y-6">
        <header class="border-b border-slate-800 pb-4 flex justify-between items-center">
          <div>
            <h1 class="text-2xl font-bold text-emerald-400">⚡ EV Charging Command Center</h1>
            <p class="text-slate-400 text-sm">Engineered by SwarmOps Autonomous Agents</p>
          </div>
          <a href="/docs" target="_blank" class="text-xs bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded border border-slate-700">Open API Docs ↗</a>
        </header>

        <!-- Role Selector -->
        <div class="bg-slate-800/80 p-5 rounded-xl border border-slate-700 flex items-center justify-between">
          <div>
            <span class="text-xs text-slate-400 uppercase tracking-wider block font-semibold">Active User Persona</span>
            <span id="role-display" class="text-lg font-bold text-emerald-400">Driver (driver_42)</span>
          </div>
          <div class="flex gap-2">
            <button onclick="setRole('driver')" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded font-medium text-sm">Act as Driver</button>
            <button onclick="setRole('operator')" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 rounded font-medium text-sm">Act as Operator</button>
          </div>
        </div>

        <!-- Interactive Actions Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Start Charging -->
          <div class="bg-slate-800/60 p-5 rounded-xl border border-slate-700 space-y-3">
            <h2 class="font-semibold text-lg flex items-center gap-2">🔌 Plug In & Charge</h2>
            <p class="text-slate-400 text-xs">Simulates driver initiating an OCPP 2.0.1 session.</p>
            <button onclick="startSession()" class="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition">
              Start Session (STN-001)
            </button>
            <div id="session-status" class="text-xs font-mono p-3 bg-slate-950 rounded border border-slate-800 min-h-[60px] text-slate-400">
              No active session. Click Start to begin.
            </div>
          </div>

          <!-- Operator: Station Management -->
          <div class="bg-slate-800/60 p-5 rounded-xl border border-slate-700 space-y-3">
            <h2 class="font-semibold text-lg flex items-center gap-2">🏢 Install Station (RBAC Test)</h2>
            <p class="text-slate-400 text-xs">Only authorized operators can provision hardware.</p>
            <button onclick="createStation()" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition">
              Provision New Station
            </button>
            <div id="rbac-status" class="text-xs font-mono p-3 bg-slate-950 rounded border border-slate-800 min-h-[60px] text-slate-400">
              Ready to test permission check.
            </div>
          </div>
        </div>

        <!-- Live JSON Console -->
        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div class="text-xs text-slate-500 uppercase tracking-wider mb-2 font-semibold">Live Server Response Log</div>
          <pre id="log" class="text-xs text-emerald-400 font-mono overflow-x-auto max-h-48">Waiting for action...</pre>
        </div>
      </div>

      <script>
        let currentToken = "";
        let currentRole = "driver";
        let activeSessionId = null;

        async function setRole(role) {
          currentRole = role;
          const res = await fetch("/auth/token", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ user_id: role + "_01", role: role })
          });
          const data = await res.json();
          currentToken = data.access_token;
          document.getElementById("role-display").innerText = role.toUpperCase() + " (" + role + "_01)";
          document.getElementById("log").innerText = "Switched to " + role + ". JWT Token acquired.";
        }

        async function startSession() {
          if (!currentToken) await setRole(currentRole);
          const res = await fetch("/sessions/start", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + currentToken
            },
            body: JSON.stringify({ connector_id: "STN-001-A", vehicle_id: "EV-TESLA-88" })
          });
          const data = await res.json();
          document.getElementById("log").innerText = JSON.stringify(data, null, 2);
          if (data.session_id) {
            activeSessionId = data.session_id;
            document.getElementById("session-status").innerHTML = 
              '<span class="text-emerald-400 font-bold">⚡ Charging Active</span><br>Session ID: ' + activeSessionId + 
              '<br><button onclick="stopSession()" class="mt-2 px-3 py-1 bg-red-600 text-white rounded text-xs">Stop & Calculate Cost</button>';
          }
        }

        async function stopSession() {
          if (!activeSessionId) return;
          const res = await fetch("/sessions/" + activeSessionId + "/stop", {
            method: "POST",
            headers: { "Authorization": "Bearer " + currentToken }
          });
          const data = await res.json();
          document.getElementById("log").innerText = JSON.stringify(data, null, 2);
          document.getElementById("session-status").innerHTML = '<span class="text-slate-400">Session complete. kWh and tariff logged.</span>';
          activeSessionId = null;
        }

        async function createStation() {
          if (!currentToken) await setRole(currentRole);
          const res = await fetch("/stations", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + currentToken
            },
            body: JSON.stringify({ station_id: "STN-NEW-01", name: "Downtown Fast Charger", max_kw: 150 })
          });
          const data = await res.json();
          document.getElementById("log").innerText = JSON.stringify(data, null, 2);
          const rbac = document.getElementById("rbac-status");
          if (res.status === 403) {
            rbac.innerHTML = '<span class="text-rose-400 font-bold">❌ 403 Forbidden</span><br>Driver is not allowed to create stations! Security policy enforced.';
          } else {
            rbac.innerHTML = '<span class="text-emerald-400 font-bold">✅ Station Created</span><br>Operator credentials verified.';
          }
        }

        setRole('driver');
      </script>
    </body>
    </html>
    """
