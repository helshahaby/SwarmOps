# Research Report — EV Charging Management API

## Requirements
- Users: registration, login, roles (driver, operator, admin)
- Charging stations: CRUD, connector types, availability
- Charging sessions: start/stop, live status, energy (kWh)
- Energy consumption: per session, per station, per user
- Reporting: daily/monthly aggregates, CSV export

## Technology comparison
| Option | Async | Validation | Ecosystem | Verdict |
|---|---|---|---|---|
| FastAPI (Python) | Native | Pydantic | Strong | Recommended |
| Express (Node) | Native | Manual/Zod | Very strong | Viable |
| Spring Boot (Java) | Reactive opt. | Bean Validation | Enterprise | Heavier |

## Standards
- OCPP 1.6J / 2.0.1 for charger communication (out of scope for v1, adapter planned)

## Risks
- Concurrent session start on one connector (race condition)
- Token leakage in logs
- Time-zone errors in reporting aggregates
